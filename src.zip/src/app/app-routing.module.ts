import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InvestmentyieldComponent } from './modules/investmentyield/investmentyield.component';
import { InvestmentyieldadminComponent } from './modules/investmentyieldadmin/investmentyieldadmin/investmentyieldadmin.component';

const routes: Routes = [
  { path: '', redirectTo: 'basket', pathMatch: 'full' },
  { path: 'basket', component: InvestmentyieldComponent },
  { path: 'admin', component: InvestmentyieldadminComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
