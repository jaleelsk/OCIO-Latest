
export class IndexMaster  {
    
         id : number | undefined;
         name : string | undefined;
         source : string | undefined;
 }
 export class Rate {
        indexId :number| undefined;
        rate: number| undefined;
 }
 export class DailyRate {
        rateDate:Date| undefined;
        rates: Rate[] = [];
 }
 export class IndexRateView {
        name : string | undefined;
        rate0 : number| undefined;
        rate1: number| undefined;
        rate2: number| undefined;
        rate3: number| undefined;
        rate4: number| undefined;
        rate5: number| undefined;
        rate6: number| undefined;
    }
