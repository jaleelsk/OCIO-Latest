import { Injectable } from '@angular/core';
import { BehaviorSubject, catchError, Observable, retry, throwError } from 'rxjs';
import { IYDataContribution, IYWorkStream } from '../models/investmentyield';
import { Basket } from '../models/iybasket';
import { IndexMaster, DailyRate } from '../models/iyindexrate';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class InvestmentYieldService {
 // Base url
 baseurl = 'https://localhost:7146';
 constructor(private http: HttpClient) {}
 // Http Headers
 httpOptions = {
   headers: new HttpHeaders({
     'Content-Type': 'application/json',
   })
  }


  //Data contributions
  private workStreams: IYWorkStream[] = [];
  private _totalDataPoints: number = 0;
  private _valuedDataPoints: number = 0;
  private _selectedWorkStream = new BehaviorSubject<number>(0);
  SelectedWorkStream$ = this._selectedWorkStream.asObservable();
  // private _basketsList = new BehaviorSubject<number>(0);
  //  BasketsData$ = this._basketsList.asObservable();
  //Basket
  private _baskets: Basket[] = [];

  GetIndexesRates(): Observable<DailyRate[]> {
    return this.http
      .get<DailyRate[]>(this.baseurl + '/api/IndexRates')
      .pipe(retry(1), catchError(this.errorHandl));
  }

  GetIndexMaster(): Observable<IndexMaster[]> {
    return this.http
      .get<IndexMaster[]>(this.baseurl + '/api/Indexes')
      .pipe(retry(1), catchError(this.errorHandl));
  }

 // Error handling
 errorHandl(error: { error: { message: string; }; status: any; message: any; }) {
  let errorMessage = '';
  if (error.error instanceof ErrorEvent) {
    // Get client-side error
    errorMessage = error.error.message;
  } else {
    // Get server-side error
    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
  }
  console.log(errorMessage);
  return throwError(() => {
    return errorMessage;
  });
}

  loadData() {
    //load from the database

    //load mock data
    this.loadMockData();
    this.loadMockBasketData();
    
  }

  private loadMockData() {
    this.workStreams.splice(0);

    let ws = new IYWorkStream();
    ws.loadWorkStream(1, "Mackay Shields", "Jacob", "Thomas", "jacob_thomas@nylim.com", new Date(), "system");
    ws.loadWorkStreamData(1, 1, "1", "CPN1 - Breakdown (coupon vs zero's)", 0, "Jacob Thomas", new Date());
    ws.loadWorkStreamData(1, 1, "1", "CPN2 - Breakdown (coupon vs zero's)", 0.2, "Jacob Thomas", new Date());
    ws.loadWorkStreamData(1, 1, "1", "Zero - Breakdown (coupon vs zero's)", 0, "Jacob Thomas", new Date());
    ws.loadWorkStreamData(1, 1, "1", "Taxable - Breakdown (coupon vs zero's)", 0.8, "Ayan Chattaraj", new Date());

    ws.loadWorkStreamData(1, 1, "1", "CPN1 - Coupon", 0.05, "Abdul Shaik", new Date());
    ws.loadWorkStreamData(1, 1, "1", "CPN2 - Coupon", 0.04, "Jacob Thomas", new Date());
    ws.loadWorkStreamData(1, 1, "1", "Zero - Coupon", 0, "Abdul Shaik", new Date());
    ws.loadWorkStreamData(1, 1, "1", "Taxable - Coupon", 0.031, "system", new Date());

    this.workStreams.push(ws);
    this._totalDataPoints += ws.TotalDataPoints;
    this._valuedDataPoints += ws.ValuedDataPoints;

    let ws1 = new IYWorkStream();
    ws1.loadWorkStream(2, "Agencies Yields", "Jacob", "Thomas", "jacob_thomas@nylim.com", new Date(), "system");
    ws1.loadWorkStreamData(1, 2, "k1", "15 Year", undefined, "system", new Date());
    ws1.loadWorkStreamData(2, 2, "k1", "10 Year", 10, "Uday Jorigala", new Date());
    ws1.loadWorkStreamData(2, 2, "k1", "5 Year", -3, "Milind Hemmady", new Date());
    ws1.loadWorkStreamData(2, 2, "k1", "3 Year", 4, "Uday Jorigala", new Date());
    ws1.loadWorkStreamData(2, 2, "k1", "2 Year", -4, "Milind Hemmady", new Date());
    this.workStreams.push(ws1);
    this._totalDataPoints += ws1.TotalDataPoints;
    this._valuedDataPoints += ws1.ValuedDataPoints;

    let ws2 = new IYWorkStream();
    ws2.loadWorkStream(3, "Agency CMBS", "Jacob", "Thomas", "jacob_thomas@nylim.com", new Date(), "system");
    ws2.loadWorkStreamData(2, 3, "k1", "5yr - 7/6.5", 25, "Jacob Thomas", new Date());
    ws2.loadWorkStreamData(2, 3, "k1", "10 yr - 12/11.5", undefined, "system", new Date());
    ws2.loadWorkStreamData(1, 3, "k1", "14 yr - 15/14.5", undefined, "system", new Date());
    this.workStreams.push(ws2);
    this._totalDataPoints += ws2.TotalDataPoints;
    this._valuedDataPoints += ws2.ValuedDataPoints;

  }

  private loadMockBasketData() {
    this._baskets.splice(0);
    
    let b1 = new Basket("ANNUITY", "Net Investable Yield");
    b1.addBasketData("Fixed Deferred Annuity", 0.0262);
    b1.addBasketData("Variable Deferred Annuity", 0.028);
    b1.addBasketData("Guaranteed Income Annuities", 0.0286);
    b1.addBasketData("Payout Annuity Participating Corp.", 0.0289);
    b1.addBasketData("Structured Settlements", 0.0287);
    this._baskets.push(b1);

    let b2 = new Basket("US LIFE LINES", "Gross Investable Yield");
    b2.addBasketData("OL-Post", 0.0341);
    b2.addBasketData("OL-Pre", 0.034);
    b2.addBasketData("Universal Life - Retail", 0.0337);
    b2.addBasketData("Universal Life - Inst.", 0.0339);
    b2.addBasketData("Universal Life - New Money", 0.034);
    b2.addBasketData("Long Term Care", 0.0346);
    b2.addBasketData("JH Closed", 0.0305);
    this._baskets.push(b2);

    let b3 = new Basket("ENTERPRISES", "Gross Investable Yield");
    b3.addBasketData("AARP", 0.0345);
    b3.addBasketData("AARP-LIP", 0.0295);
    b3.addBasketData("Membership", 0.0336);
    this._baskets.push(b3);

    let b4 = new Basket("BOLI", "Gross Investable Yield");
    b4.addBasketData("BOLI Quality", 0.0251);
    b4.addBasketData("BOLI Yield", 0.0313);
    b4.addBasketData("BOLI Yield Plus", 0.0313);
    b4.addBasketData("BOLI Tracking 5 dur", 0.0273);
    b4.addBasketData("BOLI Tracking 7 dur", 0.0301);
    this._baskets.push(b4);

    let b5 = new Basket("SMA", "Gross Investable Yield");
    b5.addBasketData("NYLIC SMA", 0.0288);
    b5.addBasketData("NYLIAC SMA", 0.0295);
    b5.addBasketData("NYLIC SMA CMS", 0.0288);
    b5.addBasketData("NYLIAC SMA CMS", 0.0289);
    this._baskets.push(b5);
  }

 get WorkStreams() {
  return this.workStreams;
}

get PercentCompleted() {
  return (this._valuedDataPoints/this._totalDataPoints);
}

getWorkStreamName(id: number) {
  let streamName = '';
  var ws = this.workStreams.find((x) => x.StreamId == id);

  if(ws != undefined) {
    streamName = ws.StreamName;
  }
  return streamName;
}

getWorkStreamData(id: number) {
  let data: IYDataContribution[] = [];
  var ws = this.workStreams.find((x) => x.StreamId == id);

  if(ws != undefined) {
    data = ws.StreamData;
  }
  return data;
}

  NotifyWorkStreamSelected(workStreamId:number) {
    this._selectedWorkStream.next(workStreamId);
  }

  get Baskets() {
    return this._baskets;
  }

  
}
