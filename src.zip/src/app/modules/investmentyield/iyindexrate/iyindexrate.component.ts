import { Component, OnDestroy, OnInit } from '@angular/core';
import { InvestmentYieldService } from 'src/app/services/investmentyield.service';
import { IndexMaster, IndexRateView } from 'src/app/models/iyindexrate';
import { forkJoin, map, Observable, Subscription } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';


@Component({
  selector: 'app-iyindexrate',
  templateUrl: './iyindexrate.component.html',
  styleUrls: ['./iyindexrate.component.css'],
})
export class IyindexrateComponent implements OnInit, OnDestroy {
  private subscription: Subscription | undefined;
  public data : IndexRateView[] =[];
  public datesArray: (Date|undefined)[]=[];
  public indexRates$ : Observable<IndexRateView[]> = forkJoin([
    this.invService.GetIndexMaster(),
    this.invService.GetIndexesRates()
  ]).pipe(
    map(ir => {
      let viewData : IndexRateView[] = [];
      let m = ir[0];
      let r = ir[1];
      m.forEach(im => {
        let v = new IndexRateView();
        v.name = im.name
        //console.log(r);
        
        v.rate0 = r[0].rates.find(rate => rate.indexId === im.id)?.rate
        v.rate1 = r[1].rates.find(rate => rate.indexId === im.id)?.rate
        v.rate2 = r[2].rates.find(rate => rate.indexId === im.id)?.rate
        v.rate3 = r[3].rates.find(rate => rate.indexId === im.id)?.rate
        v.rate4 = r[4].rates.find(rate => rate.indexId === im.id)?.rate
        v.rate5 = r[5].rates.find(rate => rate.indexId === im.id)?.rate
        v.rate6 = r[6].rates.find(rate => rate.indexId === im.id)?.rate
        viewData.push(v); 
      })
      r.map(date=>date.rateDate).forEach(d1=>this.datesArray.push(d1))      
    
      return viewData;
      
  }));

  public displayedColumns : string[] = ['name','rate0','rate1','rate2','rate3','rate4','rate5','rate6']
  
  constructor(private invService: InvestmentYieldService) {
    // this.indexRates$ = forkJoin([
    //   this.invService.GetIndexMaster(),
    //   this.invService.GetIndexesRates()
    // ]).pipe(
    //   map(ir => {
    //     let viewData : IndexRateView[] = [];
    //     let m = ir[0];
    //     let r = ir[1];
    //     m.forEach(im => {
    //       let v = new IndexRateView();
    //       v.name = im.name
    //       viewData.push(v);
    //     })
    //     return viewData;
    // }));

  }

  ngOnInit(): void {
    this.subscription = this.indexRates$.subscribe(ratedata => {
       this.data = ratedata;
       console.log(this.data);
    });
  }

  ngOnDestroy(): void {
     this.subscription?.unsubscribe();
  }

  // ngOnInit(): void {
  //   this.invService.GetIndexesRates().subscribe((data: any) => {
  //     this.indexRateDate =this.convertDate(data[0].rateDate);
  //     this.IndexRates = data[0].rates;
  //     console.log(this.indexRateDate)
  //   });
  //   this.invService.GetIndexMaster().subscribe((data: any) => {
  //     this.IndexMaster = data;
  //     this.indexData = data;
  //     this.loadIndexes();
  //     // console.log(this.indexData);
  //   });
       
  // }
  // loadIndexes(){
  //   this.indexData.forEach((element: any) => {
  //     this.IndexRates.forEach((data) => {
  //       if (data.indexId == element.id){
  //          element.rate = data.rate;
  //         // console.log(element);
  //     }});
  //   });
  // }

   convertDate(inputFormat:any) {
    function pad(s:any) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat)
    return [pad(d.getDate()), pad(d.getMonth()+1), d.getFullYear()].join('-')
  }
}
