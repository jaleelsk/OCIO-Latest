import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IYDataContribution, IYWorkStream } from 'src/app/models/investmentyield';
import { InvestmentYieldService } from 'src/app/services/investmentyield.service';

@Component({
  selector: 'app-iycontribution',
  templateUrl: './iycontribution.component.html',
  styleUrls: ['./iycontribution.component.css']
})
export class IycontributionComponent implements OnInit {
  basketStatus = 'Pending';
  dcColor = 'accent';
  streamtotal = 100;
  _selectedWorkStreamId: number = 0;
  _dp:IYDataContribution[] = [];
  selectedWorkStream: string | undefined;
  workStreams: IYWorkStream[] = [];
  dynamicForm: FormGroup;

  constructor(private _iyService: InvestmentYieldService,
              private _fb: FormBuilder) {
    this.dynamicForm = this._fb.group({
      datapoints: this._fb.array([])
    });
            
    this._iyService.SelectedWorkStream$.subscribe((workStreamId: number) => {
      this._selectedWorkStreamId = workStreamId;
      this.selectedWorkStream = this._iyService.getWorkStreamName(workStreamId);
      this.onChangeWorkStream(workStreamId);
    });

   }

  ngOnInit(): void {
    this.selectedWorkStream = '(select data contribution item)';
    this._iyService.loadData();
    this.workStreams = this._iyService.WorkStreams;
  }

  get PctComplete() {
    this.dcColor = (this._iyService.PercentCompleted == 1) ?'primary':'accent';
    return this._iyService.PercentCompleted;
  }

  private onChangeWorkStream(id: number) {
    this.deleteDataPoints();
    this._dp = this._iyService.getWorkStreamData(id);
    this._dp.forEach((dp) => {
      this.addDataPoint(dp);
    });

  }

  isWorkStreamSelected() {
    return (this._selectedWorkStreamId > 0);
  }

  get datapointsArray(): FormArray {
    return this.dynamicForm.get('datapoints') as FormArray;
  }

  DataPointDescription(i: number) {
    return this._dp[i].dataItem.keyDescription;
  }

  DataContribution(i: number) {
    return this._dp[i].contributor + ' on ' + this._dp[i].contributionDate.toLocaleDateString();
  }

  saveData() {
    this.datapointsArray.controls.forEach((c) => {
      if(c.dirty) {
        
      }
    });
  }
  
  resetData() {
    
  }

  sendContributionReminders() {
    
  }

  private newDataPoint(dp: IYDataContribution): FormGroup {
    const dpValue = (dp.dataValue == undefined) ? '': dp.dataValue;
    const datapointForm: FormGroup = this._fb.group({
      id: [dp.dataItem.id],
      desc: [dp.dataItem.keyDescription],
      val: [dpValue, Validators.required],
      edited: [dp.contributor]
    });
    
    return datapointForm;
  }

  private addDataPoint(dp: IYDataContribution) {
    this.datapointsArray.push(this.newDataPoint(dp));
  }

  private deleteDataPoints() {
    this.datapointsArray.clear();
  }
}