import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investmentyieldadmin',
  templateUrl: './investmentyieldadmin.component.html',
  styleUrls: ['./investmentyieldadmin.component.css']
})
export class InvestmentyieldadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
