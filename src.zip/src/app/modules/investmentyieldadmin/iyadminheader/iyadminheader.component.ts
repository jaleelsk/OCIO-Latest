import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iyadminheader',
  templateUrl: './iyadminheader.component.html',
  styleUrls: ['./iyadminheader.component.css']
})
export class IyadminheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
