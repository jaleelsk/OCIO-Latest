import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IyadminheaderComponent } from './iyadminheader.component';

describe('IyadminheaderComponent', () => {
  let component: IyadminheaderComponent;
  let fixture: ComponentFixture<IyadminheaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IyadminheaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IyadminheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
