import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratingpercentage',
  templateUrl: './ratingpercentage.component.html',
  styleUrls: ['./ratingpercentage.component.css']
})
export class RatingpercentageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
