import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RatingpercentageComponent } from './ratingpercentage.component';

describe('RatingpercentageComponent', () => {
  let component: RatingpercentageComponent;
  let fixture: ComponentFixture<RatingpercentageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RatingpercentageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RatingpercentageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
