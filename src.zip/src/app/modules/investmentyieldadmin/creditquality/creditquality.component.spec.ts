import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditqualityComponent } from './creditquality.component';

describe('CreditqualityComponent', () => {
  let component: CreditqualityComponent;
  let fixture: ComponentFixture<CreditqualityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreditqualityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditqualityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
