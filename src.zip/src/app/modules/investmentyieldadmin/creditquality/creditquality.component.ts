import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creditquality',
  templateUrl: './creditquality.component.html',
  styleUrls: ['./creditquality.component.css']
})
export class CreditqualityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
